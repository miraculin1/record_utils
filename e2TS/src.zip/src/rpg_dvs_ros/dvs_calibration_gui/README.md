to install the gui you have to clear your rqt cache
rm ~/.config/ros.org/rqt_gui.ini
